﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Queue<string> cola = new Queue<string>();
        cola.Enqueue("mano");
        cola.Enqueue("canasta");
        cola.Enqueue("carreta llena");
        cola.Enqueue("carreta medio llena");
        cola.Enqueue("autoservicio");

        int tiempoTotal = 0;

        while (cola.Count > 0)
        {
            string persona = cola.Dequeue();
            int tiempoAtencion = 0;

            if (persona == "mano")
            {
                tiempoAtencion = 1;
            }
            else if (persona == "canasta")
            {
                tiempoAtencion = 2;
            }
            else if (persona == "carreta llena")
            {
                tiempoAtencion = 10;
            }
            else if (persona == "carreta medio llena")
            {
                tiempoAtencion = 5;
            }
            else if (persona == "autoservicio")
            {
                tiempoAtencion = (int)(0.8 * 1);
            }

            tiempoTotal += tiempoAtencion;
        }

        Console.WriteLine("El tiempo estimado total es: " + tiempoTotal + " minutos");
    }
}


